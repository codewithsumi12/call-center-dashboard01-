import pandas as pd
import plotly.express as px

def get_metrics(df):
    avg_duration = df["Call Duration (min)"].mean()
    resolution_rate = (df["Resolved"] == "Yes").sum() / len(df)
    avg_csat = df["CSAT"].mean()
    return {
        "avg_duration": avg_duration,
        "resolution_rate": resolution_rate,
        "avg_csat": avg_csat
    }

def plot_csats(df):
    return px.box(df, x="Agent", y="CSAT", color="Agent", title="CSAT by Agent")

def plot_resolutions(df):
    counts = df.groupby(["Agent", "Resolved"]).size().reset_index(name="Count")
    return px.bar(counts, x="Agent", y="Count", color="Resolved", barmode="group")
