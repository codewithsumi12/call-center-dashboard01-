import streamlit as st
import pandas as pd
import plotly.express as px
from app.analysis import get_metrics, plot_csats, plot_resolutions

st.set_page_config(page_title="Call Center Dashboard", layout="wide")

st.title("📞 Call Center Performance Dashboard")

data = pd.read_csv("data/sample_call_data.csv")

with st.sidebar:
    st.header("Filters")
    agent_filter = st.multiselect("Select Agents", options=data["Agent"].unique(), default=data["Agent"].unique())

filtered_data = data[data["Agent"].isin(agent_filter)]

# Show metrics
metrics = get_metrics(filtered_data)
st.metric("📞 Avg Call Duration (min)", f"{metrics['avg_duration']:.2f}")
st.metric("✅ Resolution Rate", f"{metrics['resolution_rate']*100:.2f}%")
st.metric("⭐ Avg CSAT", f"{metrics['avg_csat']:.2f} / 5")

# Charts
col1, col2 = st.columns(2)

with col1:
    st.subheader("Customer Satisfaction Score")
    fig = plot_csats(filtered_data)
    st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("Resolution Rate by Agent")
    fig = plot_resolutions(filtered_data)
    st.plotly_chart(fig, use_container_width=True)
