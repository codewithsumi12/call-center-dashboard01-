# 📞 Call Center Performance Dashboard

This dashboard helps call centers track KPIs like average call duration, resolution rate, and CSAT using interactive data visualizations.

## 🚀 Features
- Agent-wise metrics
- CSAT analysis
- Resolved vs unresolved call tracking
- Easy filtering and exploration

## 📦 Tech Stack
- Streamlit
- Pandas
- Plotly

## 🛠️ Run Locally
```bash
pip install -r requirements.txt
streamlit run app/dashboard.py
```

## 📁 Sample Data
Found in `data/sample_call_data.csv`. Replace with real data to scale.
